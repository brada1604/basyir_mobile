<body style="background-image: url('/assets/image/Background.png');  background-position: center; background-size: cover;">
    <div>
        <nav class=" navbar navbar-expand-lg navbar-light" style="margin-top: 20px;">
            <a href="/pengaturan" class="nav-link text-center">
                <img src="<?= base_url(); ?>/assets/assets-mobile/icon-menu/Back.png" alt="SVG Happyku" width="30em" height="30em" />
            </a>
        </nav>
        <div class="container">
            <div class="row">
                <div class="col-md-2 text-center">
                    <h2 class="heading-section mb-5  bold-text" style="font-family: 'Inter',Arial, sans-serif; color: white; font-weight: bold;">Pengaturan</h2>
                </div>
                <div class="col-md-6">
                <div class="d-flex align-items-center justify-content-center" style="background-color: #f8f9fa; height: 550px; border-radius: 20px; margin-bottom: 100px;">
                    <div class="container">
                        <nav class=" navbar navbar-expand-lg navbar-light" style="margin-top: -200px; margin-left: -10px;">
                            <h5 style="font-family: 'Inter', Arial, sans-serif; color: #629C87;">Izinkan Untuk Melakukan Broadcast Email</h5>
                            <div class="form-check-inline form-check form-switch mb-4" style="font-family: 'Inter', Arial, sans-serif; color: #629C87; font-weight: bold;">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" checked>
                                <label class="form-check-label" for="flexSwitchCheckChecked">Ya, saya izinkan</label>
                            </div>
                            <!-- <h5 style="font-family: 'Inter', Arial, sans-serif; color: #629C87; margin-top: 10px;">Masukkan Nomor Whatsapp Anda</h5>
                            <div class="form-check form-switch form-check-inline">
                                <input type="number" class="form-control" id="whatsappNumber" style="font-family: 'Inter', Arial, sans-serif; color: #629C87; font-weight: bold;">
                            </div> -->
                        </nav>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</body>